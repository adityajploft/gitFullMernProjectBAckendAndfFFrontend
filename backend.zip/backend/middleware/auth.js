const User = require("../models/User")
const jwt = require("jsonwebtoken");
exports.isAuthentcated = async (req, res, next) => {
    try {
        const { token } = req.cookies;
        console.log("token", token)
        if (!token) {
            return res.status(400).json({ success: false, msg: "Please Login" })
        }

        const decode = await jwt.verify(token, process.env.JWT_SECERET)
        console.log("token", decode)
        req.user = await User.findById(decode._id)
        next()
    } catch (error) {
        return res.status(400).json({ success: false, msg: error.message })
    }

}

