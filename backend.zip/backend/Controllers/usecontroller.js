const User = require("../models/User");
const Post = require("../models/Post");
//Register
exports.UserRegister = async (req, res) => {
    try {
        const { name, email, password } = req.body;
        let user = await User.findOne({ email });
        if (user) {
            return res.status(400).json({ success: false, msg: "User Already Exist With This E-Mail Id" })
        }
        user = await User.create({ name, email, password, avatar: { public_id: "Sapmle_id", url: "sample_Url" } })
        var date = new Date();
        date.setTime(date.getTime() + 5 * 60 * 60 * 1000);

        const token = await user.generateToken();
        // console.log("token", token)
        res.status(200).cookie("token", token, { expires: date, httpOnly: true }).json({ success: true, userdetail: user, token: token })

    } catch (error) {
        return res.status(500).json({ success: false, msg: error.message })
    }
}

//Login

exports.Login = async (req, res) => {
    try {
        const { email, password } = req.body;
        let findUser = await User.findOne({ email }).select("+password")

        if (!findUser) {
            return res.status(400).json({ success: false, msg: "User Not Exist" })
        }

        let PasswordMatch = findUser.password == password;
        // console.log("pass", findUser)
        if (!PasswordMatch) {
            return res.status(400).json({ success: false, msg: "InValid Cretenials" })
        }

        var date = new Date();
        date.setTime(date.getTime() + 5 * 60 * 60 * 1000);

        const token = await findUser.generateToken();
        // console.log("token", token)
        res.status(200).cookie("token", token, { expires: date, httpOnly: true }).json({ success: true, userdetail: findUser, token: token })

    } catch (error) {
        return res.status(500).json({ success: false, msg: error.message })
    }
}

exports.Follow = async (req, res) => {
    try {
        const usertoFollow = await User.findById(req.params.id)
        const LoggedInUser = await User.findById(req.user._id)
        if (!usertoFollow) {
            return res.status(500).json({ success: false, msg: "User Not Found" })
        }
        // console.log("ddd1" ,LoggedInUser.following)
        if (LoggedInUser.following.includes(usertoFollow._id)) {
            // console.log("ddd2")

            const indexfollowing = LoggedInUser.following.indexOf(usertoFollow._id)
            const indexfollowers = usertoFollow.followers.indexOf(LoggedInUser._id)

            LoggedInUser.following.splice(indexfollowing, 1)
            usertoFollow.followers.splice(indexfollowers, 1)

            await LoggedInUser.save()
            await usertoFollow.save()
            res.status(200).json({ sucess: true, msg: "User Un-followed" })
        }
        else {
            LoggedInUser.following.push(usertoFollow._id)
            usertoFollow.followers.push(LoggedInUser._id)
            await LoggedInUser.save()
            await usertoFollow.save()
            res.status(200).json({ sucess: true, msg: "User-followed" })
        }
    } catch (error) {
        return res.status(500).json({ success: false, msg: error.message })

    }
}

exports.Logout = async (req, res) => {
    try {
        res.status(200).cookie("token", null, { expires: new Date(Date.now()), httpOnly: true }).json({ success: true, msg: "Logout Sucess" })
    } catch (error) {
        return res.status(500).json({ success: false, msg: error.message })

    }
}

exports.UpdatePassword = async (req, res) => {
    try {
        const { newPassword, oldPassword } = req.body;

        const user = await User.findById(req.user._id).select("+password")
        if (!oldPassword || !newPassword) {
            return res.status(500).json({ success: false, msg: "Please Provide Both Password Field" })

        }
        if (!user) {
            return res.status(500).json({ success: false, msg: "User Not Found" })
        }
        let matchPassword = user.password == oldPassword;
        if (!matchPassword) {
            return res.status(500).json({ success: false, msg: "Old Password Not Match" })
        }
        if (newPassword == user.password) {
            return res.status(500).json({ success: false, msg: "New Password Cannot Be Same As A Old Password" })

        }
        user.password = newPassword;
        await user.save();
        res.status(200).json({ sucess: true, msg: "Password Updated Success" })

    } catch (error) {
        return res.status(500).json({ success: false, msg: error.message })

    }
}

exports.UpdateProfile = async (req, res) => {
    try {
        const { name, email } = req.body;
        const user = await User.findById(req.user._id);
        if (!user) {
            return res.status(500).json({ success: false, msg: "User Not Found" })
        }
        if (name) {
            user.name = name;
        }
        if (email) {
            user.email = email;
        }
        await user.save()
        return res.status(200).json({ success: false, msg: "Profile Update Success" })
    } catch (error) {
        return res.status(500).json({ success: false, msg: error.message })

    }
}

exports.MyProfile = async (req, res) => {
    try {
        const user = await User.findById(req.user._id).populate("posts")
        // console.log("iser",user)
        res.status(200).json({ success: true, user })

    } catch (error) {
        return res.status(500).json({ success: false, msg: error.message })

    }
}