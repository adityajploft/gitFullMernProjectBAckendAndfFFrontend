const Post = require("../models/Post")
const User = require("../models/User")

exports.CreatePost = async (req, res) => {
    try {
        const newdaata = {
            caption: req.body.caption,
            Image: {
                public_id: "public_id",
                url: "https://i.pcmag.com/imagery/reviews/01pr6hmgqz7A5wX5hSQWqRs-1.fit_lim.size_625x365.v1632764534.jpg"
            },
            owner: req.user._id
        }
        const newPost = await Post.create(newdaata)

        const user = await User.findById(req.user._id)
        user.posts.push(newPost._id)
        await user.save();

        res.status(200).json({
            success: true,
            message: "Uploaded SuccessFully"

        })
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message

        })
    }
}

exports.deletePost = async (req, res) => {

    try {

        //  console.log("id",id)
        const post = await Post.findById(req.params.id);
        if (!post) {
            return res.status(500).json({ success: false, msg: "No Post With This Id" })
        }
        if (post.owner.toString() !== req.user._id.toString()) {
            return res.status(400).json({ success: false, msg: "You Are Not Authorized To Delete This Post" })

        }
        await post.remove();
        const user = await User.findById(req.user._id);

        const index = user.posts.indexOf(req.params.id)
        user.posts.splice(index, 1);
        await user.save();

        return res.status(200).json({ success: true, msg: "Post Deleted SuccessFully" })
    } catch (error) {
        return res.status(500).json({ success: false, msg: error.message })

    }
}

exports.LikeAndUnLikePost = async (req, res) => {
    // console.log("dsd",req.params.id)
    try {
        const post = await Post.findById(req.params.id);
        if (!post) {
            return res.status(500).json({ success: false, msg: "No Post With This Id" })
        }
        if (post.likes.includes(req.user._id)) {
            const index = post.likes.indexOf(req.user._id)
            post.likes.splice(index, 1)
            await post.save()
            return res.status(200).json({ success: true, msg: "UnLiked" })
        }
        else {
            post.likes.push(req.user._id)
            await post.save();
            return res.status(200).json({ success: true, msg: "Liked" })
        }
    } catch (error) {
        return res.status(500).json({ success: false, msg: error.message })
    }
}

exports.getPostOfFollowing = async (req, res) => {
    try {
        // const user = await User.findById(req.user._id).populate("following", "posts")

        const user = await User.findById(req.user._id);

        const post = await Post.find({
            owner:{
                $in:user.following
            }
        })

        // const post = user.post
        return res.status(200).json({ success: true, post })

    } catch (error) {
        return res.status(500).json({ success: false, msg: error.message })

    }

}