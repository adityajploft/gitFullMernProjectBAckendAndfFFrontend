const app = require("./app")
// require("dotenv").config({path:"./config/config.env"})
const { connectDatabase } = require("./config/database")
connectDatabase();
let port = process.env.PORT; 
app.listen(port,()=>{
    console.log("Server Started ON: ",port)
})