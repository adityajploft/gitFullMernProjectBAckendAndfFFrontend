const express = require("express");
const { UserRegister, Login, Follow, Logout,UpdatePassword ,UpdateProfile,MyProfile} = require("../Controllers/usecontroller");
const { CreatePost, LikeAndUnLikePost ,deletePost, getPostOfFollowing} = require("../Controllers/PostController");
const { isAuthentcated } = require("../middleware/auth");

const router = express.Router();
//postouter
router.route("/post/upload").post(isAuthentcated, CreatePost)
router.route("/post/like/:id").get(isAuthentcated, LikeAndUnLikePost)
router.route("/post/delete/:id").delete(isAuthentcated, deletePost)
router.route("/post/getPostoffollowing").get(isAuthentcated, getPostOfFollowing)
router.route("/post/getPostoffollowing").get(isAuthentcated, getPostOfFollowing)
// router.route("/post/getPostoffollowing").get(isAuthentcated, )


//userrouter
router.route("/user/register").post(UserRegister)
router.route("/user/login").post(Login)
router.route("/user/follow/:id").get(isAuthentcated,Follow)
router.route("/user/logout").post(isAuthentcated,Logout)
router.route("/user/updatepassword").post(isAuthentcated,UpdatePassword)
router.route("/user/updateprofile").post(isAuthentcated,UpdateProfile)
router.route("/user/profile").get(isAuthentcated,MyProfile)

module.exports = router