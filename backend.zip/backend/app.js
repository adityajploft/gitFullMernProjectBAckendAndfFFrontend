const express = require("express")
const app = express()
require("dotenv").config({ path: "./config/config.env" })
const cookieParser = require("cookie-parser")

app.use(express.json())
app.use(express.urlencoded({extended:true}));
app.use(cookieParser());

const Routes = require("./Routes/index")
app.use("/api/v1", Routes)
module.exports = app; 