const mongoose = require("mongoose");
// require("dotenv").config({path:"./config/config.env"})
exports.connectDatabase = ()=>{
     // console.log(process.env.MONGO_URI,"df");
     mongoose.connect(process.env.MONGO_URI).then(con=>console.log("DB CONNECTED")).catch((err)=>console.log("err" ,err))
}