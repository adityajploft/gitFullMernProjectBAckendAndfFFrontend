const mongoose = require("mongoose")
const jwt = require("jsonwebtoken")
const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Please Enter A Name"]
    },
    avatar: {
        public_id: String,
        url: String
    },
    email: {
        type: String,
        required: [true, "Please Enter A Name"],
        unique: [true, "Please Enter A Unique Email"],

    },
    password: {
        type: String,
        required: [true, "Please Enter A Password"],
        select: false
    },
    posts: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Post"
        }
    ],
    followers: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User"
        }

    ],
    following: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User"
        }

    ]
})
userSchema.methods.generateToken = function () {
    return jwt.sign({ _id: this._id }, process.env.JWT_SECERET)
}

module.exports = mongoose.model("User", userSchema)